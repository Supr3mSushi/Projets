$(document).ready(function(){
  $('.sidenav').sidenav();
  $('.parallax').parallax();

});

// setInterval(function(){
//   next();
// },3000) 
